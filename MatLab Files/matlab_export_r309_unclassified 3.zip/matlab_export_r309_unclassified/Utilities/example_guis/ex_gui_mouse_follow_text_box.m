function ex_gui_mouse_follow()

close all;
hfig = figure;

set(hfig,'WindowButtonMotionFcn',@mouseMove)
% set(hfig,'WindowButtonDownFcn',@mouseClickDown)
% set(hfig,'WindowButtonUpFcn',@mouseClickUp)

% hax = axes;
data.htb = uicontrol('Style','Text', 'Units','Normalized', ...
    'Position',[0 0 1.0 0.05], ...
    'HorizontalAlignment','right',...
    'String','this is a text box');

% get(htb)

%     function mouseMove(obj,eventdata)
% 
%         c = get(gca,'CurrentPoint');
% 
%         eventdata
% 
%         title(gca,['(x,y) = (',num2str(c(1,1)),', ',num2str(c(1,2)),')'])
% 
%     end

% data.mouseClickStatus = 0;

guidata(hfig,data)


%     function mouseClickDown(obj,eventdata,varargin)
%         data = guidata(obj);
%         %eventdata
%         data.mouseClickStatus = 1;
%         guidata(obj,data);
%         
%     end
% 
%     function mouseClickUp(obj,eventdata)
%         data = guidata(obj);
%         %eventdata
%         data.mouseClickStatus = 0;
%         guidata(obj,data);
%     end

    function mouseMove(obj,eventdata)
        data = guidata(obj);
        %eventdata
        
%         clc
%         if(data.mouseClickStatus == 1)
%             disp('mouse button down')
%             % PUT ACTIONS YOU WANT TO TAKE HERE
%             % like getting the point on the axes
        fmtstr = '%10.5f';
        pt = get(gca,'CurrentPoint');
        set(data.htb,'String',['(x,y) = (',num2str(pt(1,1),fmtstr),', ',num2str(pt(1,2),fmtstr),')'])
            
%         end
        
        guidata(obj,data);
    end


end