close all; clear all; clc


% figure;
figure_with_pointer_location;

x = linspace(0,100,1000);
y = randn(1,1000);
plot(x,y)


