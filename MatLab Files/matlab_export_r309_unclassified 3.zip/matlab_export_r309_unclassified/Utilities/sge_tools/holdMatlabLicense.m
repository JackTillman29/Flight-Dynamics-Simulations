function holdMatlabLicense()

% login to input machines and run matlab
unix(

% keep open until done with GRID jobs

end