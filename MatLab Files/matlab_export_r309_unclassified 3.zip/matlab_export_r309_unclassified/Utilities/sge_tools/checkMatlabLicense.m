function checkMatlabLicense()

% get machines that SGE has access to
!qhost




end