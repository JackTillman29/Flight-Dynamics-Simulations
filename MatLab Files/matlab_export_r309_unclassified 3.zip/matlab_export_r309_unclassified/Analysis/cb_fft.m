function cb_fft(varargin)

timeWindow = get(gca,'XLim')
cb_WaveFftStruct(timeWindow);

end