function n = columns(x)

n = size(x,2);

end