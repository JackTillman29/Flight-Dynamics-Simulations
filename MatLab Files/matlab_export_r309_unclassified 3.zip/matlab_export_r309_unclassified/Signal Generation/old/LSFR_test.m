close all;
clear all;
clc;
a=LSFR(5,[0 0 1 0 1],1)
a.step()
a
a.step()
a
a.step()
a
a.step()
a